/**
 * 
 */
package com.gracefully;

import java.io.File;
import java.util.ResourceBundle;

import com.gracefully.util.FileUtils;
import com.gracefully.util.StringValueUtils;

/**
 * @author Canni
 *
 */
public class GenBat {

	private static String sfn = null;
	private static String pd = null;
	private static String lp = null;
	private static String jp = null;
	private static String sep = null;
	private static String mc = null;
	private static int system = 1;
	private static String param = null;
	private static final int WINDOWS = 1;
	private static final int LINUX = 2;
	private static final String wrap = "\n";
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ResourceBundle rb = ResourceBundle.getBundle("genbatconfig");
//		sfn = ConfigManager.getConfigProperty("scriptfilename");
//		pd = ConfigManager.getConfigProperty("project-dir");
//		lp = ConfigManager.getConfigProperty("lib-path");
//		jp = ConfigManager.getConfigProperty("jre-path");
//		mc = ConfigManager.getConfigProperty("mainClass");
//		system = StringValueUtils.getInt(ConfigManager.getConfigProperty("system"));
		sfn = rb.getString("scriptfilename");
		pd = rb.getString("project-dir");
		lp = rb.getString("lib-path");
		jp = rb.getString("jre-path");
		mc = rb.getString("mainClass");
		system = StringValueUtils.getInt(rb.getString("system"));
		param = rb.getString("mainClassParam");
		
		valid(pd);

		if(system == LINUX){
			sep = ":";
		}else{
			sep = ";";
		}
		
		File[] libfiles = new File(lp).listFiles();
		StringBuffer LIB_PATH = new StringBuffer();
		LIB_PATH.append(".").append(sep).append(getLIB_PATH()).append(sep);
		for(int i= 0;i<libfiles.length;i++){
			if(!libfiles[i].getName().endsWith(".jar"))
				continue;
			String name = getLIB_PATH()+File.separatorChar+libfiles[i].getName()+sep;
			LIB_PATH.append(name);
		}
		String javacommand = jp+File.separatorChar+"bin"+File.separatorChar+"java";
		
		StringBuffer script = new StringBuffer();
		if(system == WINDOWS){
			script.append("echo off").append(wrap);
			script.append("set LIB_PATH=").append(lp).append(wrap);
			script.append("set CLASS_PATH=").append(LIB_PATH).append(wrap);
			script.append("cmd.exe /k ").append(javacommand);
			script.append(" -D").append(param).append(" -cp %CLASS_PATH% ").append(mc);
		}else if(system == LINUX){
			script.append("LIB_PATH=").append(lp).append(wrap);
			script.append("CLASS_PATH=").append(LIB_PATH).append(wrap);
			script.append(javacommand);
			script.append(" -D").append(param).append(" -classpath $CLASS_PATH ").append(mc);
		}else{
			System.out.println("error system");
			System.exit(system);
		}
		
		FileUtils.writeStringToFile(pd+File.separatorChar+sfn, script.toString());
	}

	private static void valid(String dir){
		File file = new File(dir);
		if(!file.exists()){
			file.mkdirs();
		}
	}
	
	private static String getLIB_PATH(){
		String rv = "%LIB_PATH%";
		if(system == LINUX){
			rv = "$LIB_PATH";
		}
		return rv ;
	}
}
