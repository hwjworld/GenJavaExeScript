chmod +x setEnv.sh
. "setEnv.sh"
$JAVA_HOME/bin/java -classpath $CLASS_PATH com.gracefully.GenBat